<aside class="main-sidebar">

    <!-- sidebar-->
    <section class="sidebar">

        <!-- Sidebar user  -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo e(asset('user-profile.png')); ?> " class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo e(\Auth::user()->name); ?></p>
                <!-- Status -->
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>
        <!-- search form -->
        <!-- <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
                <input type="text" name="q" class="form-control" placeholder="Search...">
                <span class="input-group-btn">
              <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
              </button>
            </span>
            </div>
        </form> -->
        <!-- /.search form -->

        <!-- Sidebar Menu -->
        <ul class="sidebar-menu" data-widget="tree">
            <!-- <li class="header">Functions</li> -->
            <li><a href="<?php echo e(url('/home')); ?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
            <li><a href="<?php echo e(route('stocks.index')); ?>"><i class="fa fa-list"></i> <span>Stock Taken</span></a></li>
            <!-- <li><a href="<?php echo e(route('legacies.index')); ?>"><i class="fa fa-list"></i> <span>Current Stock</span></a></li> -->
            <li><a href="<?php echo e(route('warehouses.index')); ?>"><i class="fa fa-list"></i> <span>Warehouse</span></a></li>
            <li><a href="<?php echo e(route('bays.index')); ?>"><i class="fa fa-cubes"></i> <span>Bays</span></a></li>
            <li><a href="<?php echo e(route('owners.index')); ?>"><i class="fa fa-users"></i> <span>Farm Owners</span></a></li>
            <li><a href="<?php echo e(route('grades.index')); ?>"><i class="fa fa-list"></i> <span>Tea Grades</span></a></li>
            <li><a href="<?php echo e(route('gardens.index')); ?>"><i class="fa fa-list"></i> <span>Gardens</span></a></li>
            <li><a href="<?php echo e(route('packages.index')); ?>"><i class="fa fa-cubes"></i> <span>Package Types</span></a></li>
            <li><a href="<?php echo e(route('user.index')); ?>"><i class="fa fa-user-secret"></i> <span>System Users</span></a></li>








        </ul>
        <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>
