
<div class="box box-success">
                <table class="table table-bordered table-hover table-striped">
                    <thead>
                        <tr>
                            <th>Warehouse</th>
                            <th>Total Bags</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bagsPerWarehouse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouseId => $totalBags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($warehouse[$warehouseId]); ?></td>
                                <td><?php echo e($totalBags); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
</div>