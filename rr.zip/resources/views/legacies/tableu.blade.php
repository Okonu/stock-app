<div class="box box-success">

        <div class="box-header">
            <h3 class="box-title">Imported Stock</h3>
        </div>

        <!-- <div class="box-header">
            <a onclick="addForm()" class="btn btn-success" ><i class="fa fa-plus"></i> Add Customers</a>
        </div> -->


        <!-- /.box-header -->
        <div class="box-body">
            <table id="customer-table" class="table table-bordered table-hover table-striped">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Garden</th>
                    <th>Grade</th>
                    <th>Invoice</th>
                    <th>Package Number</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
        <!-- /.box-body -->
    </div>